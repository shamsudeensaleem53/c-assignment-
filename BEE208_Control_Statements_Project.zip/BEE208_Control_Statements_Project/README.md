# BEE 208 — Control Statements in C++
## Practical Lab Activity | Complete Project Package

**Faculty:** Engineering  
**Department:** Electrical/Electronic Engineering  
**Lab Activity Set:** 15 Practical Questions  

---

## Project Description

This project contains complete solutions for all 15 BEE 208 practical lab questions covering Control Statements in C++. Each question includes an algorithm, pseudocode, ASCII flowchart, fully commented C++ programme, and at least two test cases with expected outputs.

All programmes use only beginner-level C++ — no classes, templates, vectors, pointers, or advanced STL. Every programme compiles and runs with g++ using only `iostream` and basic control structures.

---

## List of All 15 Questions

| No. | Title | Control Statement |
|-----|-------|-------------------|
| Q1  | Voltage Level Classifier | if...else if...else |
| Q2  | Current Overload Checker | if...else |
| Q3  | Scholarship Eligibility for Engineering Student | if...else |
| Q4  | Electrical Component Menu | switch |
| Q5  | Power Rating Menu | switch |
| Q6  | Series Resistor Calculator | for loop |
| Q7  | Average Voltage from Sensor Readings | for loop |
| Q8  | Count Safe Current Readings | for loop with if...else |
| Q9  | Current Monitoring System | while loop |
| Q10 | Battery Voltage Monitoring | while loop |
| Q11 | Password Access to Control Panel | while loop |
| Q12 | Menu-Driven Electrical Calculator | do...while with switch |
| Q13 | Stop Test on Low Battery | for loop with break |
| Q14 | Skip Invalid Temperature Readings | for loop with continue |
| Q15 | Electrical Load Limit Checker | while loop |

---

## How to Compile and Run in VS Code

Make sure you have **g++** installed. If you are on Windows, install **MinGW** or use the **WSL** terminal. On Linux/Mac, g++ is usually available by default.

### Step 1 — Open a Terminal in VS Code
Go to `Terminal > New Terminal` in the top menu.

### Step 2 — Navigate to the Question Folder
```bash
cd Question01
```

### Step 3 — Compile the Programme
```bash
g++ question1_voltage_classifier.cpp -o question1
```

### Step 4 — Run the Programme
```bash
./question1
```
*(On Windows Command Prompt use:* `question1.exe`*)*

---

## Compile Commands for All 15 Questions

```bash
# Question 1
g++ Question01/question1_voltage_classifier.cpp -o q1 && ./q1

# Question 2
g++ Question02/question2_overload_checker.cpp -o q2 && ./q2

# Question 3
g++ Question03/question3_scholarship_eligibility.cpp -o q3 && ./q3

# Question 4
g++ Question04/question4_component_menu.cpp -o q4 && ./q4

# Question 5
g++ Question05/question5_power_rating_menu.cpp -o q5 && ./q5

# Question 6
g++ Question06/question6_series_resistor.cpp -o q6 && ./q6

# Question 7
g++ Question07/question7_average_voltage.cpp -o q7 && ./q7

# Question 8
g++ Question08/question8_safe_current_count.cpp -o q8 && ./q8

# Question 9
g++ Question09/question9_current_monitoring.cpp -o q9 && ./q9

# Question 10
g++ Question10/question10_battery_monitoring.cpp -o q10 && ./q10

# Question 11
g++ Question11/question11_password_access.cpp -o q11 && ./q11

# Question 12
g++ Question12/question12_electrical_calculator.cpp -o q12 && ./q12

# Question 13
g++ Question13/question13_low_battery_break.cpp -o q13 && ./q13

# Question 14
g++ Question14/question14_temperature_continue.cpp -o q14 && ./q14

# Question 15
g++ Question15/question15_load_limit_checker.cpp -o q15 && ./q15
```

---

## Folder Structure

```
BEE208_Control_Statements_Project/
├── README.md
├── Question01/
│   ├── question1_voltage_classifier.cpp
│   ├── algorithm.md
│   ├── pseudocode.md
│   ├── flowchart.md
│   └── test_cases.md
├── Question02/
│   ├── question2_overload_checker.cpp
│   ├── algorithm.md
│   ├── pseudocode.md
│   ├── flowchart.md
│   └── test_cases.md
├── Question03/
│   └── (same structure)
├── Question04/
│   └── (same structure)
├── Question05/
│   └── (same structure)
├── Question06/
│   └── (same structure)
├── Question07/
│   └── (same structure)
├── Question08/
│   └── (same structure)
├── Question09/
│   └── (same structure)
├── Question10/
│   └── (same structure)
├── Question11/
│   └── (same structure)
├── Question12/
│   └── (same structure)
├── Question13/
│   └── (same structure)
├── Question14/
│   └── (same structure)
└── Question15/
    ├── question15_load_limit_checker.cpp
    ├── algorithm.md
    ├── pseudocode.md
    ├── flowchart.md
    └── test_cases.md
```

---

## Marking Guide (Per Question)

| Component    | Marks |
|--------------|-------|
| Algorithm    | 2     |
| Pseudocode   | 2     |
| Flowchart    | 2     |
| C++ Programme | 4    |
| **Total**    | **10** |

**Maximum Total: 150 marks (15 questions × 10 marks)**

---

## Libraries Used

All 15 programmes use **only**:
```cpp
#include <iostream>
using namespace std;
```

No advanced libraries, classes, templates, pointers, or STL containers are used anywhere in this project.
