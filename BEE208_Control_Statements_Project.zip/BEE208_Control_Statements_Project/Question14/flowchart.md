# Question 14: Skip Invalid Temperature Readings Using Continue
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +-------------------------------+
        | totalTemp=0, validCount=0     |
        | invalidCount=0, i=1           |
        +-------------------------------+
                 |
                 v
        +------------------+
        |    i <= 10 ?     |---NO---> [ Calculate average if validCount > 0 ]
        +------------------+                        |
                 | YES                               v
                 v                         [ DISPLAY average temp ]
        +---------------------------+               |
        | INPUT temperature (C)     |               v
        +---------------------------+       +------------------+
                 |                          |       END        |
                 v                          +------------------+
        +---------------------------+
        | temperature < 0 ?         |
        +---------------------------+
           YES |              | NO
               v              v
    +------------------+  +---------------------------+
    | DISPLAY "INVALID"|  | DISPLAY "Valid"           |
    | invalidCount++   |  | totalTemp += temperature  |
    | CONTINUE         |  | validCount++              |
    +------------------+  +---------------------------+
        (next i)               |
                               v
                          [ i = i + 1 ]
                               |
                          (back to loop)
```
