# Question 14: Skip Invalid Temperature Readings Using Continue
## Pseudocode

```
BEGIN

    DECLARE temperature AS REAL
    DECLARE totalTemp AS REAL = 0
    DECLARE validCount AS INTEGER = 0
    DECLARE invalidCount AS INTEGER = 0
    DECLARE averageTemp AS REAL
    DECLARE i AS INTEGER

    DISPLAY "Enter 10 temperature readings (invalid = below 0 C):"

    FOR i = 1 TO 10 DO
        DISPLAY "Enter Temperature Reading", i, "(in degrees C):"
        INPUT temperature

        IF temperature < 0 THEN
            DISPLAY "INVALID (skipped)"
            invalidCount = invalidCount + 1
            CONTINUE
        END IF

        DISPLAY temperature, "C - Valid"
        totalTemp = totalTemp + temperature
        validCount = validCount + 1

    END FOR

    IF validCount > 0 THEN
        averageTemp = totalTemp / validCount
        DISPLAY "Average Temperature =", averageTemp, "degrees C"
    ELSE
        DISPLAY "No valid readings. Average cannot be calculated."
    END IF

END
```
