# Question 14: Skip Invalid Temperature Readings Using Continue
## Test Cases

---

### Test Case 1 — Mix of Valid and Invalid Readings
**Input:** 25, -5, 30, 28, -3, 35, 22, -1, 27, 29

**Expected Output:**
```
>> Reading 1: 25 C - Valid
>> Reading 2: -5 C - INVALID (skipped)
>> Reading 3: 30 C - Valid
>> Reading 4: 28 C - Valid
>> Reading 5: -3 C - INVALID (skipped)
>> Reading 6: 35 C - Valid
>> Reading 7: 22 C - Valid
>> Reading 8: -1 C - INVALID (skipped)
>> Reading 9: 27 C - Valid
>> Reading 10: 29 C - Valid

Total Readings   : 10
Valid Readings   : 7
Invalid Readings : 3
Average Temp     : 28 degrees C
```

---

### Test Case 2 — All Valid Readings
**Input:** 20, 22, 21, 23, 20, 24, 22, 21, 23, 24

**Expected Output:**
```
Valid Readings   : 10
Invalid Readings : 0
Average Temp     : 22 degrees C
```
