# Question 14: Skip Invalid Temperature Readings Using Continue
## Algorithm

**Step 1:** START

**Step 2:** Declare `temperature`, `totalTemp = 0`, `validCount = 0`, `invalidCount = 0`, `averageTemp`, `i`

**Step 3:** Display title and invalid threshold (below 0 °C)

**Step 4:** FOR i = 1 TO 10 DO:
   - Input `temperature`
   - IF temperature < 0 THEN:
       - Display "INVALID (skipped)"
       - Increment `invalidCount`
       - CONTINUE (skip to next iteration)
   - Display "Valid"
   - Add `temperature` to `totalTemp`
   - Increment `validCount`

**Step 5:** IF validCount > 0:
   - `averageTemp = totalTemp / validCount`
   - Display `averageTemp` in °C
   - ELSE: Display "No valid readings"

**Step 6:** END
