# Question 5: Power Rating Menu
## Pseudocode

```
BEGIN

    DECLARE choice AS INTEGER
    DECLARE voltage, current, power, time, resistance, energy AS REAL

    DISPLAY "Power Rating Calculator Menu"
    DISPLAY "1. Calculate DC Power"
    DISPLAY "2. Calculate Resistance using Ohm's Law"
    DISPLAY "3. Calculate Energy Consumption"
    INPUT choice

    SWITCH choice
        CASE 1:
            INPUT voltage, current
            power = voltage * current
            DISPLAY "DC Power =", power, "W"

        CASE 2:
            INPUT voltage, current
            IF current = 0 THEN
                DISPLAY "Error: Current cannot be zero."
            ELSE
                resistance = voltage / current
                DISPLAY "Resistance =", resistance, "Ohms"
            END IF

        CASE 3:
            INPUT power, time
            energy = power * time
            DISPLAY "Energy =", energy, "Wh"

        DEFAULT:
            DISPLAY "Invalid selection."
    END SWITCH

END
```
