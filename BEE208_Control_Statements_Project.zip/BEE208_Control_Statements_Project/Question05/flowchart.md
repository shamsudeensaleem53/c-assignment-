# Question 5: Power Rating Menu
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +------------------------------+
        | DISPLAY Calculation Menu     |
        | 1-Power, 2-Resistance,       |
        | 3-Energy                     |
        +------------------------------+
                 |
                 v
        +---------------------------+
        | INPUT choice              |
        +---------------------------+
                 |
                 v
        +---------------------------+
        |    SWITCH (choice)        |
        +---------------------------+
         |         |         |      |
         1         2         3   default
         |         |         |      |
         v         v         v      v
      [Power]  [Resistance][Energy][Invalid]
      P=V*I    R=V/I      E=P*t
         |         |         |
         v         v         v
      [Display result with units]
                 |
                 v
        +------------------+
        |       END        |
        +------------------+
```
