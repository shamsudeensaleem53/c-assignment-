# Question 5: Power Rating Menu
## Algorithm

**Step 1:** START

**Step 2:** Display program title and menu options (1, 2, 3)

**Step 3:** Declare variables: `choice`, `voltage`, `current`, `power`, `time`, `resistance`, `energy`

**Step 4:** Accept user's menu `choice`

**Step 5:** Use switch:
   - Case 1: Input voltage and current → Calculate Power = Voltage × Current → Display result in W
   - Case 2: Input voltage and current → Calculate Resistance = Voltage / Current → Display result in Ohms
   - Case 3: Input power and time → Calculate Energy = Power × Time → Display result in Wh
   - Default: Display "Invalid selection"

**Step 6:** END
