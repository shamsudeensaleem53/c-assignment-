# Question 5: Power Rating Menu
## Test Cases

---

### Test Case 1 — Calculate DC Power
**Input:** choice = 1, Voltage = 230 V, Current = 5 A

**Expected Output:**
```
--- DC Power Calculation ---
Enter Voltage (in Volts): 230
Enter Current (in Amperes): 5
DC Power = 230 V x 5 A
DC Power = 1150 W
```

---

### Test Case 2 — Calculate Energy Consumption
**Input:** choice = 3, Power = 1500 W, Time = 3 h

**Expected Output:**
```
--- Energy Consumption Calculation ---
Enter Power (in Watts): 1500
Enter Time (in Hours): 3
Energy = 1500 W x 3 h
Energy = 4500 Wh
```
