# Question 11: Password Access to Control Panel
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +---------------------------+
        | correctPassword = 2080    |
        +---------------------------+
                 |
                 v
        +---------------------------+
        | INPUT password            |
        +---------------------------+
                 |
                 v
        +------------------------------+
        | password != correctPassword? |---NO---> [ DISPLAY "Access granted
        +------------------------------+           to control panel." ]
                 | YES                                      |
                 v                                          v
        +---------------------------+            +------------------+
        | DISPLAY "Incorrect        |            |       END        |
        | password. Try again."     |            +------------------+
        +---------------------------+
                 |
                 v
        +---------------------------+
        | INPUT password            |
        +---------------------------+
                 |
                 (back to password check)
```
