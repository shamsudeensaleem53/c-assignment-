# Question 11: Password Access to Control Panel
## Algorithm

**Step 1:** START

**Step 2:** Declare `password` as integer; set `correctPassword = 2080`

**Step 3:** Display title and prompt user to enter password

**Step 4:** Input `password`

**Step 5:** WHILE password != 2080 DO:
   - Display "Incorrect password. Please try again."
   - Input `password` again

**Step 6:** After loop (correct password entered):
   - Display "Access granted to control panel."

**Step 7:** END
