# Question 11: Password Access to Control Panel
## Pseudocode

```
BEGIN

    DECLARE password AS INTEGER
    DECLARE correctPassword AS INTEGER = 2080

    DISPLAY "Control Panel Access System"
    DISPLAY "Enter password:"
    INPUT password

    WHILE password != correctPassword DO
        DISPLAY "Incorrect password. Please try again."
        DISPLAY "Enter password:"
        INPUT password
    END WHILE

    DISPLAY "Access granted to control panel."

END
```
