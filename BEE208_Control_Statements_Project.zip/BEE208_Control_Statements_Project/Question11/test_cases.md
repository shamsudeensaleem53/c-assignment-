# Question 11: Password Access to Control Panel
## Test Cases

---

### Test Case 1 — Wrong then Correct Password
**Input sequence:** 1234, 9999, 2080

**Expected Output:**
```
Enter password: 1234
  >> Incorrect password. Please try again.
Enter password: 9999
  >> Incorrect password. Please try again.
Enter password: 2080

============================================
  Access granted to control panel.
============================================
```

---

### Test Case 2 — Correct Password on First Try
**Input:** 2080

**Expected Output:**
```
Enter password: 2080

============================================
  Access granted to control panel.
============================================
```
