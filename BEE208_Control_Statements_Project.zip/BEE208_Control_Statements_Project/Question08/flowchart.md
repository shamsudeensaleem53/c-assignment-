# Question 8: Count Safe Current Readings
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +-------------------------------+
        | safeCount = 0                 |
        | unsafeCount = 0, i = 1        |
        +-------------------------------+
                 |
                 v
        +------------------+
        |    i <= 8 ?      |---NO---> [ DISPLAY safeCount, unsafeCount ]
        +------------------+                      |
                 | YES                             v
                 v                        +------------------+
        +---------------------------+     |       END        |
        | INPUT currentReading (A)  |     +------------------+
        +---------------------------+
                 |
                 v
        +---------------------------+
        | currentReading <= 10 ?    |
        +---------------------------+
           YES |             | NO
               v             v
        [safeCount++]  [unsafeCount++]
        [DISP SAFE]    [DISP UNSAFE]
               |             |
               +------+------+
                      |
                      v
              [ i = i + 1 ]
                      |
               (back to loop)
```
