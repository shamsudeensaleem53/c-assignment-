# Question 8: Count Safe Current Readings
## Test Cases

---

### Test Case 1
**Input:** 5, 8, 12, 10, 3, 15, 9, 7

**Expected Output:**
```
Safe Readings   : 6 (10 A or below)
Unsafe Readings : 2 (above 10 A)
```
(5, 8, 10, 3, 9, 7 are safe; 12, 15 are unsafe)

---

### Test Case 2
**Input:** 20, 25, 30, 18, 22, 11, 19, 14

**Expected Output:**
```
Safe Readings   : 0 (10 A or below)
Unsafe Readings : 8 (above 10 A)
```
