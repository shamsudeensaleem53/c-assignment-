# Question 8: Count Safe Current Readings
## Algorithm

**Step 1:** START

**Step 2:** Declare `currentReading`, `safeCount = 0`, `unsafeCount = 0`, `i`

**Step 3:** Display heading and safe limit (10 A)

**Step 4:** FOR i = 1 TO 8:
   - Input `currentReading`
   - IF `currentReading <= 10` THEN
       - Display "SAFE", increment `safeCount`
   - ELSE
       - Display "UNSAFE", increment `unsafeCount`

**Step 5:** Display `safeCount` and `unsafeCount`

**Step 6:** END
