# Question 8: Count Safe Current Readings
## Pseudocode

```
BEGIN

    DECLARE currentReading AS REAL
    DECLARE safeCount AS INTEGER = 0
    DECLARE unsafeCount AS INTEGER = 0
    DECLARE i AS INTEGER

    DISPLAY "Enter 8 current readings:"

    FOR i = 1 TO 8 DO
        DISPLAY "Enter Current Reading", i, "(in Amperes):"
        INPUT currentReading

        IF currentReading <= 10 THEN
            DISPLAY "SAFE"
            safeCount = safeCount + 1
        ELSE
            DISPLAY "UNSAFE"
            unsafeCount = unsafeCount + 1
        END IF

    END FOR

    DISPLAY "Safe Readings   :", safeCount
    DISPLAY "Unsafe Readings :", unsafeCount

END
```
