# Question 6: Series Resistor Calculator
## Pseudocode

```
BEGIN

    DECLARE resistorValue AS REAL
    DECLARE totalResistance AS REAL = 0
    DECLARE i AS INTEGER

    DISPLAY "Series Resistor Calculator"
    DISPLAY "Enter the values of 5 resistors:"

    FOR i = 1 TO 5 DO
        DISPLAY "Enter value of Resistor R", i, "(in Ohms):"
        INPUT resistorValue
        totalResistance = totalResistance + resistorValue
    END FOR

    DISPLAY "Total Series Resistance =", totalResistance, "Ohms"

END
```
