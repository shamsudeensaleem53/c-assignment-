# Question 6: Series Resistor Calculator
## Algorithm

**Step 1:** START

**Step 2:** Display program title: "Series Resistor Calculator"

**Step 3:** Declare variables: `resistorValue` (double), `totalResistance` (double, initialised to 0), `i` (int)

**Step 4:** Prompt user that 5 resistor values will be entered

**Step 5:** Use a for loop from i = 1 to 5:
   - Prompt: "Enter value of Resistor Ri (in Ohms):"
   - Read `resistorValue`
   - Add `resistorValue` to `totalResistance`

**Step 6:** After the loop, display the total resistance in Ohms

**Step 7:** END
