# Question 6: Series Resistor Calculator
## Test Cases

---

### Test Case 1
**Input:** R1=100, R2=220, R3=330, R4=470, R5=150 (all in Ohms)

**Expected Output:**
```
Total Series Resistance = 1270 Ohms
```

---

### Test Case 2
**Input:** R1=10, R2=10, R3=10, R4=10, R5=10 (all in Ohms)

**Expected Output:**
```
Total Series Resistance = 50 Ohms
```
