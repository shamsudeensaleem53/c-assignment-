# Question 6: Series Resistor Calculator
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +-------------------------------+
        | DECLARE resistorValue         |
        | totalResistance = 0           |
        | i = 1                         |
        +-------------------------------+
                 |
                 v
        +------------------+
        |    i <= 5 ?      |---NO---> [ DISPLAY totalResistance in Ohms ]
        +------------------+                      |
                 | YES                             v
                 v                        +------------------+
        +---------------------------+     |       END        |
        | INPUT resistorValue (Ohms)|     +------------------+
        +---------------------------+
                 |
                 v
        +------------------------------------------+
        | totalResistance = totalResistance +       |
        |                   resistorValue           |
        +------------------------------------------+
                 |
                 v
        +------------------+
        |    i = i + 1     |
        +------------------+
                 |
                 (back to i <= 5 check)
```
