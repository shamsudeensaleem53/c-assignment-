# Question 3: Scholarship Eligibility for Engineering Student
## Algorithm

**Step 1:** START

**Step 2:** Display program title: "Scholarship Eligibility Checker"

**Step 3:** Declare a variable called `gpa` as type double

**Step 4:** Prompt user: "Enter your GPA (0.0 - 4.0):"

**Step 5:** Read the value of `gpa`

**Step 6:** Check if gpa is greater than or equal to 3.5:
   - IF YES → Display "Eligible for engineering scholarship."
   - ELSE → Display "Not eligible for engineering scholarship."

**Step 7:** END
