# Question 3: Scholarship Eligibility for Engineering Student
## Test Cases

---

### Test Case 1 — Eligible
**Input:** GPA = 3.7

**Expected Output:**
```
============================================
  BEE 208 - Scholarship Eligibility Checker
============================================
Enter your GPA (0.0 - 4.0): 3.7

GPA Entered : 3.7
Result      : Eligible for engineering scholarship.
============================================
```

---

### Test Case 2 — Not Eligible
**Input:** GPA = 2.8

**Expected Output:**
```
============================================
  BEE 208 - Scholarship Eligibility Checker
============================================
Enter your GPA (0.0 - 4.0): 2.8

GPA Entered : 2.8
Result      : Not eligible for engineering scholarship.
============================================
```
