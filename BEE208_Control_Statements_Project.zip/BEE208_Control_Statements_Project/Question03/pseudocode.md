# Question 3: Scholarship Eligibility for Engineering Student
## Pseudocode

```
BEGIN

    DECLARE gpa AS REAL

    DISPLAY "Scholarship Eligibility Checker"
    DISPLAY "Enter your GPA (0.0 - 4.0):"
    INPUT gpa

    IF gpa >= 3.5 THEN
        DISPLAY "Eligible for engineering scholarship."
    ELSE
        DISPLAY "Not eligible for engineering scholarship."
    END IF

END
```
