# Question 3: Scholarship Eligibility for Engineering Student
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +------------------+
        | DECLARE gpa      |
        +------------------+
                 |
                 v
        +---------------------------+
        | INPUT gpa (0.0 to 4.0)   |
        +---------------------------+
                 |
                 v
        +------------------+
        |   gpa >= 3.5 ?   |
        +------------------+
           YES |        | NO
               v        v
  +--------------------+  +------------------------------+
  | DISPLAY "Eligible  |  | DISPLAY "Not eligible for    |
  | for engineering    |  | engineering scholarship."    |
  | scholarship."      |  +------------------------------+
  +--------------------+              |
               |                      |
               +----------------------+
                          |
                          v
                 +------------------+
                 |       END        |
                 +------------------+
```
