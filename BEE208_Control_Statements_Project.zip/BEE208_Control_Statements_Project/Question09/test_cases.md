# Question 9: Current Monitoring System
## Test Cases

---

### Test Case 1
**Input sequence:** 5, 7, 10, 12

**Expected Output:**
```
>> Current: 5 A - SAFE
>> Current: 7 A - SAFE
>> Current: 10 A - SAFE
Current Reading : 12 A
Status          : Overcurrent detected. Monitoring stopped.
```

---

### Test Case 2
**Input sequence:** 15 (immediate overload)

**Expected Output:**
```
Current Reading : 15 A
Status          : Overcurrent detected. Monitoring stopped.
```
