# Question 9: Current Monitoring System
## Algorithm

**Step 1:** START

**Step 2:** Declare variable `current` as double

**Step 3:** Display title and safe limit (10 A)

**Step 4:** Input first current reading

**Step 5:** WHILE current <= 10 DO:
   - Display "SAFE" message with current value
   - Input next current reading

**Step 6:** When loop ends (current > 10):
   - Display "Overcurrent detected. Monitoring stopped."

**Step 7:** END
