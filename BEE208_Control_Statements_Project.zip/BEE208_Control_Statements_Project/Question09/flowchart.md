# Question 9: Current Monitoring System
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +---------------------------+
        | INPUT current (A)         |
        +---------------------------+
                 |
                 v
        +------------------+
        | current <= 10 ?  |---NO---> [ DISPLAY "Overcurrent detected.
        +------------------+           Monitoring stopped." ]
                 | YES                          |
                 v                              v
        +---------------------------+  +------------------+
        | DISPLAY current, "SAFE"   |  |       END        |
        +---------------------------+  +------------------+
                 |
                 v
        +---------------------------+
        | INPUT next current (A)    |
        +---------------------------+
                 |
                 (back to current <= 10 check)
```
