# Question 9: Current Monitoring System
## Pseudocode

```
BEGIN

    DECLARE current AS REAL

    DISPLAY "Current Monitoring System (limit = 10 A)"
    DISPLAY "Enter current reading (in Amperes):"
    INPUT current

    WHILE current <= 10 DO
        DISPLAY current, "A - SAFE"
        DISPLAY "Enter current reading (in Amperes):"
        INPUT current
    END WHILE

    DISPLAY "Overcurrent detected. Monitoring stopped."

END
```
