# Question 1: Voltage Level Classifier
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +------------------+
        | DECLARE voltage  |
        +------------------+
                 |
                 v
        +---------------------------+
        | INPUT voltage (in Volts)  |
        +---------------------------+
                 |
                 v
        +------------------+
        | voltage < 0 ?    |---YES---> [ DISPLAY "Invalid voltage reading" ]
        +------------------+                          |
                 | NO                                 |
                 v                                    |
        +------------------+                         |
        | 0 <= voltage <=  |---YES---> [ DISPLAY "Low voltage" ]
        |      50 ?        |                          |
        +------------------+                         |
                 | NO                                 |
                 v                                    |
        +------------------+                         |
        | 51 <= voltage <= |---YES---> [ DISPLAY "Normal voltage" ]
        |      240 ?       |                          |
        +------------------+                         |
                 | NO                                 |
                 v                                    |
        +------------------+                         |
        | 241 <= voltage   |---YES---> [ DISPLAY "High voltage" ]
        |    <= 415 ?      |                          |
        +------------------+                         |
                 | NO                                 |
                 v                                    |
        +---------------------------+                 |
        | DISPLAY "Dangerous        |                 |
        |          voltage"         |                 |
        +---------------------------+                 |
                 |                                    |
                 +------------------------------------+
                 |
                 v
        +------------------+
        |       END        |
        +------------------+
```
