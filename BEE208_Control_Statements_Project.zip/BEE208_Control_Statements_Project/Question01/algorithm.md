# Question 1: Voltage Level Classifier
## Algorithm

**Step 1:** START

**Step 2:** Display program title: "Voltage Level Classifier"

**Step 3:** Declare a variable called `voltage` of type double

**Step 4:** Prompt the user: "Enter the voltage reading (in Volts):"

**Step 5:** Read the voltage value entered by the user

**Step 6:** Check if voltage is less than 0
   - If YES → Display "Invalid voltage reading" → Go to Step 12

**Step 7:** Check if voltage is between 0 V and 50 V (inclusive)
   - If YES → Display "Low voltage" → Go to Step 12

**Step 8:** Check if voltage is between 51 V and 240 V (inclusive)
   - If YES → Display "Normal voltage" → Go to Step 12

**Step 9:** Check if voltage is between 241 V and 415 V (inclusive)
   - If YES → Display "High voltage" → Go to Step 12

**Step 10:** Check if voltage is above 415 V
   - If YES → Display "Dangerous voltage" → Go to Step 12

**Step 11:** (All conditions covered above)

**Step 12:** Display the voltage value with classification result

**Step 13:** END
