# Question 1: Voltage Level Classifier
## Test Cases

---

### Test Case 1
**Input:** voltage = -5

**Expected Output:**
```
============================================
       BEE 208 - Voltage Level Classifier
============================================
Enter the voltage reading (in Volts): -5

Voltage Reading : -5 V
Classification  : Invalid voltage reading
============================================
```

---

### Test Case 2
**Input:** voltage = 220

**Expected Output:**
```
============================================
       BEE 208 - Voltage Level Classifier
============================================
Enter the voltage reading (in Volts): 220

Voltage Reading : 220 V
Classification  : Normal voltage
============================================
```

---

### Test Case 3 (Bonus)
**Input:** voltage = 500

**Expected Output:**
```
============================================
       BEE 208 - Voltage Level Classifier
============================================
Enter the voltage reading (in Volts): 500

Voltage Reading : 500 V
Classification  : Dangerous voltage
============================================
```
