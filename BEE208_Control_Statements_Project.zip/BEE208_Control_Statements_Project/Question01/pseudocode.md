# Question 1: Voltage Level Classifier
## Pseudocode

```
BEGIN

    DECLARE voltage AS REAL

    DISPLAY "Voltage Level Classifier"
    DISPLAY "Enter the voltage reading (in Volts):"
    INPUT voltage

    IF voltage < 0 THEN
        DISPLAY "Invalid voltage reading"

    ELSE IF voltage >= 0 AND voltage <= 50 THEN
        DISPLAY "Low voltage"

    ELSE IF voltage >= 51 AND voltage <= 240 THEN
        DISPLAY "Normal voltage"

    ELSE IF voltage >= 241 AND voltage <= 415 THEN
        DISPLAY "High voltage"

    ELSE
        DISPLAY "Dangerous voltage"

    END IF

END
```
