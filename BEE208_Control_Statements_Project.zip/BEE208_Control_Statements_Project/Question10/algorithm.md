# Question 10: Battery Voltage Monitoring
## Algorithm

**Step 1:** START

**Step 2:** Declare `voltage` as double

**Step 3:** Display title and minimum voltage (12 V)

**Step 4:** Input first battery voltage reading

**Step 5:** WHILE voltage >= 12 DO:
   - Display "Voltage OK"
   - Input next voltage reading

**Step 6:** After loop (voltage < 12):
   - Display "Battery voltage low. Recharge required."

**Step 7:** END
