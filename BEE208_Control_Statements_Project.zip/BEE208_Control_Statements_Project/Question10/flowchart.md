# Question 10: Battery Voltage Monitoring
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +---------------------------+
        | INPUT voltage (V)         |
        +---------------------------+
                 |
                 v
        +------------------+
        | voltage >= 12 ?  |---NO---> [ DISPLAY "Battery voltage low.
        +------------------+           Recharge required." ]
                 | YES                          |
                 v                              v
        +---------------------------+  +------------------+
        | DISPLAY voltage, "OK"     |  |       END        |
        +---------------------------+  +------------------+
                 |
                 v
        +---------------------------+
        | INPUT next voltage (V)    |
        +---------------------------+
                 |
                 (back to voltage >= 12 check)
```
