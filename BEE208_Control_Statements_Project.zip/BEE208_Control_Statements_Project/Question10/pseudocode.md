# Question 10: Battery Voltage Monitoring
## Pseudocode

```
BEGIN

    DECLARE voltage AS REAL

    DISPLAY "Battery Voltage Monitoring (minimum = 12 V)"
    DISPLAY "Enter battery voltage reading (in Volts):"
    INPUT voltage

    WHILE voltage >= 12 DO
        DISPLAY voltage, "V - OK"
        DISPLAY "Enter battery voltage reading (in Volts):"
        INPUT voltage
    END WHILE

    DISPLAY "Battery voltage low. Recharge required."

END
```
