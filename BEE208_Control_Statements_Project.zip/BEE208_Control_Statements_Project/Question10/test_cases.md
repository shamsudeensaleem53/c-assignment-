# Question 10: Battery Voltage Monitoring
## Test Cases

---

### Test Case 1
**Input sequence:** 14.5, 13.2, 12.0, 11.8

**Expected Output:**
```
>> Voltage: 14.5 V - OK
>> Voltage: 13.2 V - OK
>> Voltage: 12 V - OK
Battery Voltage : 11.8 V
Status          : Battery voltage low. Recharge required.
```

---

### Test Case 2
**Input sequence:** 9.0 (immediately low)

**Expected Output:**
```
Battery Voltage : 9 V
Status          : Battery voltage low. Recharge required.
```
