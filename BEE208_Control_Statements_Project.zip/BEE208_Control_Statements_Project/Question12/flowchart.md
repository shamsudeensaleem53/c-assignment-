# Question 12: Menu-Driven Electrical Calculator
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
    +------------------------+  <-----------+
    | DISPLAY Menu           |              |
    | 1-Power, 2-Resistance, |              |
    | 3-Energy, 4-Exit       |              |
    +------------------------+              |
                 |                          |
                 v                          |
    +---------------------------+           |
    | INPUT choice              |           |
    +---------------------------+           |
                 |                          |
                 v                          |
    +---------------------------+           |
    |    SWITCH (choice)        |           |
    +---------------------------+           |
      |      |      |      |                |
      1      2      3      4  (default)     |
      |      |      |      |      |         |
      v      v      v      v      v         |
   [Power][Resist][Energy][Exit][Invalid]   |
      |      |      |      |                |
      v      v      v      |                |
   [Calc] [Calc] [Calc]   |                |
   [Display result]       |                |
                          |                |
                          v                |
                 +------------------+      |
                 | choice != 4 ?    |--YES-+
                 +------------------+
                          | NO
                          v
                 +------------------+
                 |       END        |
                 +------------------+
```
