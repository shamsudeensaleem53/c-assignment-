# Question 12: Menu-Driven Electrical Calculator
## Pseudocode

```
BEGIN

    DECLARE choice AS INTEGER
    DECLARE voltage, current, power, time, resistance, energy AS REAL

    DO
        DISPLAY "1. Calculate Power"
        DISPLAY "2. Calculate Resistance"
        DISPLAY "3. Calculate Energy"
        DISPLAY "4. Exit"
        INPUT choice

        SWITCH choice
            CASE 1:
                INPUT voltage, current
                power = voltage * current
                DISPLAY "Power =", power, "W"

            CASE 2:
                INPUT voltage, current
                IF current = 0 THEN
                    DISPLAY "Error: Current cannot be zero."
                ELSE
                    resistance = voltage / current
                    DISPLAY "Resistance =", resistance, "Ohms"
                END IF

            CASE 3:
                INPUT power, time
                energy = power * time
                DISPLAY "Energy =", energy, "Wh"

            CASE 4:
                DISPLAY "Exiting..."

            DEFAULT:
                DISPLAY "Invalid selection."
        END SWITCH

    WHILE choice != 4

END
```
