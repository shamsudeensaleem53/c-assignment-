# Question 12: Menu-Driven Electrical Calculator
## Algorithm

**Step 1:** START

**Step 2:** Declare variables: `choice`, `voltage`, `current`, `power`, `time`, `resistance`, `energy`

**Step 3:** DO the following:
   a. Display menu: 1-Power, 2-Resistance, 3-Energy, 4-Exit
   b. Input `choice`
   c. SWITCH on `choice`:
      - Case 1: Input V and I → Power = V × I → Display in W
      - Case 2: Input V and I → Resistance = V / I → Display in Ohms
      - Case 3: Input P and T → Energy = P × T → Display in Wh
      - Case 4: Display "Exiting..."
      - Default: Display "Invalid selection"

**Step 4:** WHILE choice != 4 (keep repeating menu)

**Step 5:** END
