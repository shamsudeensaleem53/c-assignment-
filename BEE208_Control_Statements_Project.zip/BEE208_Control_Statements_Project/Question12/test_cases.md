# Question 12: Menu-Driven Electrical Calculator
## Test Cases

---

### Test Case 1 — Calculate Power then Exit
**Input:** choice=1, V=240, I=10, then choice=4

**Expected Output:**
```
--- MAIN MENU ---
  1. Calculate Power
  2. Calculate Resistance
  3. Calculate Energy
  4. Exit
Enter your choice: 1

--- Power Calculation ---
Enter Voltage (in Volts): 240
Enter Current (in Amperes): 10
Power = 240 V x 10 A = 2400 W

--- MAIN MENU ---
Enter your choice: 4
Exiting the calculator. Goodbye!
```

---

### Test Case 2 — Calculate Energy then Exit
**Input:** choice=3, P=1000, T=5, then choice=4

**Expected Output:**
```
--- MAIN MENU ---
Enter your choice: 3

--- Energy Calculation ---
Enter Power (in Watts): 1000
Enter Time (in Hours): 5
Energy = 1000 W x 5 h = 5000 Wh

--- MAIN MENU ---
Enter your choice: 4
Exiting the calculator. Goodbye!
```
