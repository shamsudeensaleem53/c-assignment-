# Question 2: Current Overload Checker
## Test Cases

---

### Test Case 1 — Overload Detected
**Input:**
- Rated Current = 15 A
- Measured Current = 20 A

**Expected Output:**
```
============================================
      BEE 208 - Current Overload Checker
============================================
Enter the rated current of the circuit breaker (in Amperes): 15
Enter the measured current in the circuit (in Amperes): 20

Rated Current   : 15 A
Measured Current: 20 A
Status          : Overload detected. Circuit breaker should trip.
============================================
```

---

### Test Case 2 — Safe Limit
**Input:**
- Rated Current = 30 A
- Measured Current = 18 A

**Expected Output:**
```
============================================
      BEE 208 - Current Overload Checker
============================================
Enter the rated current of the circuit breaker (in Amperes): 30
Enter the measured current in the circuit (in Amperes): 18

Rated Current   : 30 A
Measured Current: 18 A
Status          : Current is within safe limit.
============================================
```
