# Question 2: Current Overload Checker
## Pseudocode

```
BEGIN

    DECLARE ratedCurrent AS REAL
    DECLARE measuredCurrent AS REAL

    DISPLAY "Current Overload Checker"
    DISPLAY "Enter the rated current of the circuit breaker (in Amperes):"
    INPUT ratedCurrent

    DISPLAY "Enter the measured current in the circuit (in Amperes):"
    INPUT measuredCurrent

    DISPLAY "Rated Current   :", ratedCurrent, "A"
    DISPLAY "Measured Current:", measuredCurrent, "A"

    IF measuredCurrent > ratedCurrent THEN
        DISPLAY "Overload detected. Circuit breaker should trip."
    ELSE
        DISPLAY "Current is within safe limit."
    END IF

END
```
