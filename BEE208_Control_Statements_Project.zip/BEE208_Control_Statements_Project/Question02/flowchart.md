# Question 2: Current Overload Checker
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +-----------------------------+
        | DECLARE ratedCurrent        |
        | DECLARE measuredCurrent     |
        +-----------------------------+
                 |
                 v
        +-----------------------------+
        | INPUT ratedCurrent (A)      |
        +-----------------------------+
                 |
                 v
        +-----------------------------+
        | INPUT measuredCurrent (A)   |
        +-----------------------------+
                 |
                 v
        +-----------------------------+
        | DISPLAY both current values |
        +-----------------------------+
                 |
                 v
        +--------------------------------+
        | measuredCurrent > ratedCurrent |
        +--------------------------------+
           YES |               | NO
               v               v
  +----------------------+   +---------------------------+
  | DISPLAY "Overload    |   | DISPLAY "Current is       |
  | detected. Circuit    |   | within safe limit."       |
  | breaker should trip."|   +---------------------------+
  +----------------------+               |
               |                         |
               +-------------------------+
                          |
                          v
                 +------------------+
                 |       END        |
                 +------------------+
```
