# Question 2: Current Overload Checker
## Algorithm

**Step 1:** START

**Step 2:** Display program title: "Current Overload Checker"

**Step 3:** Declare variables: `ratedCurrent` and `measuredCurrent` as type double

**Step 4:** Prompt user: "Enter the rated current of the circuit breaker (in Amperes):"

**Step 5:** Read `ratedCurrent`

**Step 6:** Prompt user: "Enter the measured current in the circuit (in Amperes):"

**Step 7:** Read `measuredCurrent`

**Step 8:** Display both values with labels and units

**Step 9:** Compare measuredCurrent with ratedCurrent:
   - IF measuredCurrent > ratedCurrent THEN
       - Display: "Overload detected. Circuit breaker should trip."
   - ELSE
       - Display: "Current is within safe limit."

**Step 10:** END
