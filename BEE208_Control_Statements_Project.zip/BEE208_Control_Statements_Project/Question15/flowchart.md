# Question 15: Electrical Load Limit Checker
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +-------------------------------+
        | totalLoad = 0                 |
        | applianceCount = 0            |
        | loadLimit = 3000              |
        +-------------------------------+
                 |
                 v
        +-----------------------------+
        | totalLoad <= 3000 ?         |---NO---> [ DISPLAY final summary ]
        +-----------------------------+                    |
                 | YES                                     v
                 v                              +------------------+
        +---------------------------+           |       END        |
        | INPUT appliancePower (W)  |           +------------------+
        +---------------------------+
                 |
                 v
        +------------------------------------------+
        | totalLoad = totalLoad + appliancePower   |
        | applianceCount = applianceCount + 1      |
        +------------------------------------------+
                 |
                 v
        +---------------------------+
        | DISPLAY totalLoad         |
        +---------------------------+
                 |
                 v
        +-----------------------------+
        | totalLoad > 3000 ?          |---YES---> [ DISPLAY "Load limit
        +-----------------------------+            exceeded." ] --> BREAK
                 | NO
                 v
        [ DISPLAY "Load within limit." ]
                 |
                 (back to while check)
```
