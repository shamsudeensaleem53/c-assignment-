# Question 15: Electrical Load Limit Checker
## Test Cases

---

### Test Case 1 — Limit Exceeded After 4 Appliances
**Input sequence:** 800, 1200, 700, 500

**Expected Output:**
```
>> Appliance 1: 800 W added. Total Load: 800 W   - within limit
>> Appliance 2: 1200 W added. Total Load: 2000 W - within limit
>> Appliance 3: 700 W added. Total Load: 2700 W  - within limit
>> Appliance 4: 500 W added. Total Load: 3200 W

!! Load limit exceeded!
!! Do not add more appliances.

Total Appliances : 4
Final Total Load : 3200 W
Warning: Load limit of 3000 W has been exceeded!
```

---

### Test Case 2 — Single Large Appliance Exceeds Limit
**Input:** 3500 W

**Expected Output:**
```
>> Appliance 1: 3500 W added. Total Load: 3500 W

!! Load limit exceeded!
!! Do not add more appliances.

Total Appliances : 1
Final Total Load : 3500 W
Warning: Load limit of 3000 W has been exceeded!
```
