# Question 15: Electrical Load Limit Checker
## Algorithm

**Step 1:** START

**Step 2:** Declare `appliancePower`, `totalLoad = 0`, `applianceCount = 0`, `loadLimit = 3000`

**Step 3:** Display title and load limit (3000 W)

**Step 4:** WHILE totalLoad <= 3000 DO:
   - Input `appliancePower`
   - `totalLoad = totalLoad + appliancePower`
   - Increment `applianceCount`
   - Display current total load
   - IF totalLoad > 3000 THEN:
       - Display "Load limit exceeded. Do not add more appliances."
       - BREAK

**Step 5:** Display final total load and appliance count

**Step 6:** END
