# Question 15: Electrical Load Limit Checker
## Pseudocode

```
BEGIN

    DECLARE appliancePower AS REAL
    DECLARE totalLoad AS REAL = 0
    DECLARE applianceCount AS INTEGER = 0
    DECLARE loadLimit AS REAL = 3000

    DISPLAY "Electrical Load Limit Checker (limit = 3000 W)"

    WHILE totalLoad <= loadLimit DO
        DISPLAY "Enter appliance power rating (in Watts):"
        INPUT appliancePower

        totalLoad = totalLoad + appliancePower
        applianceCount = applianceCount + 1

        DISPLAY "Total Load so far:", totalLoad, "W"

        IF totalLoad > loadLimit THEN
            DISPLAY "Load limit exceeded. Do not add more appliances."
            BREAK
        END IF

        DISPLAY "Load within limit. You may add more."

    END WHILE

    DISPLAY "Total Appliances :", applianceCount
    DISPLAY "Final Total Load :", totalLoad, "W"

END
```
