# Question 13: Stop Test on Low Battery Using Break
## Algorithm

**Step 1:** START

**Step 2:** Declare `batteryVoltage` as double, `i` as integer

**Step 3:** Display title and low battery threshold (10.5 V)

**Step 4:** FOR i = 1 TO 10 DO:
   - Input `batteryVoltage`
   - IF batteryVoltage < 10.5 THEN:
       - Display "Low battery detected. Test stopped."
       - BREAK (exit loop immediately)
   - ELSE:
       - Display "Battery voltage normal."

**Step 5:** Display "Battery test complete."

**Step 6:** END
