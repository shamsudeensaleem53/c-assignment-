# Question 13: Stop Test on Low Battery Using Break
## Test Cases

---

### Test Case 1 — Low Battery Detected at Reading 3
**Input sequence:** 12.5, 11.8, 10.1

**Expected Output:**
```
>> Reading 1: 12.5 V - Battery voltage normal.
>> Reading 2: 11.8 V - Battery voltage normal.
>> Reading 3: 10.1 V
>> Low battery detected. Test stopped.
Battery test complete.
```

---

### Test Case 2 — All 10 Readings Normal
**Input sequence:** 12.0, 12.1, 12.2, 11.9, 12.5, 12.3, 11.8, 12.0, 12.4, 11.5

**Expected Output:**
```
>> Reading 1: 12 V - Battery voltage normal.
>> Reading 2: 12.1 V - Battery voltage normal.
...
>> Reading 10: 11.5 V - Battery voltage normal.
Battery test complete.
```
