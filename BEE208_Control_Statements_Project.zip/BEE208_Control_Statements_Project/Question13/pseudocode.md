# Question 13: Stop Test on Low Battery Using Break
## Pseudocode

```
BEGIN

    DECLARE batteryVoltage AS REAL
    DECLARE i AS INTEGER

    DISPLAY "Battery Voltage Test (threshold = 10.5 V)"

    FOR i = 1 TO 10 DO
        DISPLAY "Enter Battery Voltage Reading", i, "(in Volts):"
        INPUT batteryVoltage

        IF batteryVoltage < 10.5 THEN
            DISPLAY "Low battery detected. Test stopped."
            BREAK
        ELSE
            DISPLAY "Battery voltage normal."
        END IF

    END FOR

    DISPLAY "Battery test complete."

END
```
