# Question 13: Stop Test on Low Battery Using Break
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +------------------+
        |    i = 1         |
        +------------------+
                 |
                 v
        +------------------+
        |    i <= 10 ?     |---NO---> [ DISPLAY "Battery test complete." ]
        +------------------+                      |
                 | YES                             v
                 v                        +------------------+
        +---------------------------+     |       END        |
        | INPUT batteryVoltage (V)  |     +------------------+
        +---------------------------+
                 |
                 v
        +-----------------------------+
        | batteryVoltage < 10.5 ?     |
        +-----------------------------+
           YES |                 | NO
               v                 v
    +----------------------+  +---------------------------+
    | DISPLAY "Low battery |  | DISPLAY "Battery voltage  |
    | detected. Test       |  |  normal."                 |
    | stopped."            |  +---------------------------+
    +----------------------+        |
               |                    v
           [BREAK]             [ i = i + 1 ]
               |                    |
               v                    (back to i <= 10)
    [ DISPLAY "Battery test complete." ]
               |
               v
        +------------------+
        |       END        |
        +------------------+
```
