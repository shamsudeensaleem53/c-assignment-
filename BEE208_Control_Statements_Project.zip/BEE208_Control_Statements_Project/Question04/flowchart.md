# Question 4: Electrical Component Menu
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +---------------------------+
        | DISPLAY Menu Options      |
        | (1-Resistor, 2-Capacitor, |
        |  3-Diode, 4-Transistor,   |
        |  5-LED)                   |
        +---------------------------+
                 |
                 v
        +---------------------------+
        | INPUT choice              |
        +---------------------------+
                 |
                 v
        +---------------------------+
        |    SWITCH (choice)        |
        +---------------------------+
          |    |    |    |    |    |
          1    2    3    4    5  default
          |    |    |    |    |    |
          v    v    v    v    v    v
        [Resistor][Capacitor][Diode][Transistor][LED][Invalid]
                 |
                 v
        +------------------+
        |       END        |
        +------------------+
```
