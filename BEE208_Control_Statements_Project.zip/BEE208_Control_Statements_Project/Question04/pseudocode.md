# Question 4: Electrical Component Menu
## Pseudocode

```
BEGIN

    DECLARE choice AS INTEGER

    DISPLAY "Electrical Component Menu"
    DISPLAY "1. Resistor"
    DISPLAY "2. Capacitor"
    DISPLAY "3. Diode"
    DISPLAY "4. Transistor"
    DISPLAY "5. LED"
    DISPLAY "Enter your choice (1-5):"
    INPUT choice

    SWITCH choice
        CASE 1: DISPLAY "Resistor: Used to limit current in a circuit."
        CASE 2: DISPLAY "Capacitor: Used to store and release electrical energy."
        CASE 3: DISPLAY "Diode: Allows current to flow in one direction only."
        CASE 4: DISPLAY "Transistor: Used as a switch or amplifier in circuits."
        CASE 5: DISPLAY "LED: A Light Emitting Diode that converts electricity to light."
        DEFAULT: DISPLAY "Invalid selection."
    END SWITCH

END
```
