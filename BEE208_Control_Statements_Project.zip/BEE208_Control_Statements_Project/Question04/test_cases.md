# Question 4: Electrical Component Menu
## Test Cases

---

### Test Case 1 — Valid Selection (Capacitor)
**Input:** choice = 2

**Expected Output:**
```
============================================
   BEE 208 - Electrical Component Menu
============================================
Select an electrical component:
  1. Resistor
  2. Capacitor
  3. Diode
  4. Transistor
  5. LED
--------------------------------------------
Enter your choice (1-5): 2

Description: Capacitor: Used to store and release electrical energy.
============================================
```

---

### Test Case 2 — Invalid Selection
**Input:** choice = 9

**Expected Output:**
```
============================================
   BEE 208 - Electrical Component Menu
============================================
Select an electrical component:
  1. Resistor
  2. Capacitor
  3. Diode
  4. Transistor
  5. LED
--------------------------------------------
Enter your choice (1-5): 9

Description: Invalid selection. Please choose a number from 1 to 5.
============================================
```
