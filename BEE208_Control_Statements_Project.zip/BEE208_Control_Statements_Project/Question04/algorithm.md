# Question 4: Electrical Component Menu
## Algorithm

**Step 1:** START

**Step 2:** Display program title: "Electrical Component Menu"

**Step 3:** Declare variable `choice` as type integer

**Step 4:** Display the menu:
   - 1. Resistor
   - 2. Capacitor
   - 3. Diode
   - 4. Transistor
   - 5. LED

**Step 5:** Prompt user: "Enter your choice (1-5):"

**Step 6:** Read `choice`

**Step 7:** Use switch statement to match the choice:
   - Case 1 → Display description of Resistor
   - Case 2 → Display description of Capacitor
   - Case 3 → Display description of Diode
   - Case 4 → Display description of Transistor
   - Case 5 → Display description of LED
   - Default → Display "Invalid selection"

**Step 8:** END
