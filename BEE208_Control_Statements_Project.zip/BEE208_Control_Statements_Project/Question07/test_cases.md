# Question 7: Average Voltage from Sensor Readings
## Test Cases

---

### Test Case 1
**Input:** 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 (all 5 V)

**Expected Output:**
```
Total Voltage   = 50 V
Number of Readings = 10
Average Voltage = 5 V
```

---

### Test Case 2
**Input:** 10, 12, 11, 13, 9, 10, 12, 11, 10, 12

**Expected Output:**
```
Total Voltage   = 110 V
Number of Readings = 10
Average Voltage = 11 V
```
