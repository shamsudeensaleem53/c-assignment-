# Question 7: Average Voltage from Sensor Readings
## Pseudocode

```
BEGIN

    DECLARE voltageReading AS REAL
    DECLARE totalVoltage AS REAL = 0
    DECLARE averageVoltage AS REAL
    DECLARE i AS INTEGER

    DISPLAY "Enter 10 voltage readings:"

    FOR i = 1 TO 10 DO
        DISPLAY "Enter Reading", i, "(in Volts):"
        INPUT voltageReading
        totalVoltage = totalVoltage + voltageReading
    END FOR

    averageVoltage = totalVoltage / 10

    DISPLAY "Total Voltage   =", totalVoltage, "V"
    DISPLAY "Average Voltage =", averageVoltage, "V"

END
```
