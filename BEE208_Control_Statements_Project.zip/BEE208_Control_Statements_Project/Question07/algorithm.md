# Question 7: Average Voltage from Sensor Readings
## Algorithm

**Step 1:** START

**Step 2:** Declare `voltageReading`, `totalVoltage = 0`, `averageVoltage`, `i`

**Step 3:** Display prompt for 10 readings

**Step 4:** FOR i = 1 TO 10:
   - Input `voltageReading`
   - `totalVoltage = totalVoltage + voltageReading`

**Step 5:** `averageVoltage = totalVoltage / 10`

**Step 6:** Display `totalVoltage` and `averageVoltage` in V

**Step 7:** END
