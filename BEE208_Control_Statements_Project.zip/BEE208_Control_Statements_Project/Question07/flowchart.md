# Question 7: Average Voltage from Sensor Readings
## Flowchart (ASCII Text-Based)

```
        +------------------+
        |      START       |
        +------------------+
                 |
                 v
        +------------------------------+
        | totalVoltage = 0, i = 1      |
        +------------------------------+
                 |
                 v
        +------------------+
        |    i <= 10 ?     |---NO---> [ averageVoltage = totalVoltage / 10 ]
        +------------------+                        |
                 | YES                               v
                 v                     [ DISPLAY totalVoltage, averageVoltage ]
        +---------------------------+               |
        | INPUT voltageReading (V)  |               v
        +---------------------------+       +------------------+
                 |                          |       END        |
                 v                          +------------------+
        +------------------------------------------+
        | totalVoltage = totalVoltage + voltageReading |
        +------------------------------------------+
                 |
                 v
        +------------------+
        |    i = i + 1     |
        +------------------+
                 |
                 (back to i <= 10 check)
```
